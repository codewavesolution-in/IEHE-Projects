function openEventModal(id){
    const ev = events.find(x=>x.id==id);
    if(!ev) return;
  
    eventModalContent.innerHTML = `
      <h2 style="margin-bottom:8px">${ev.title}</h2>
      <div><strong>Department:</strong> <span class="dept-tag">${ev.department}</span></div>
      <p><strong>Date:</strong> ${formatFriendlyDate(ev.date)} at ${ev.time}</p>
      <p><strong>Registration deadline:</strong> ${formatFriendlyDate(ev.lastRegDate)}</p>
      <p><strong>Registrations:</strong> ${ev.registrations || 0}/${ev.maxRegistrations || 0}</p>
      <p style="margin-top:12px">${ev.description || ''}</p>
      <div style="margin-top:14px;display:flex;gap:8px">
        ${ev.regLink ? `
        <a class="btn btn-primary" href="${ev.regLink}" target="_blank">Open Registration Form</a>
        ` : `<span style="color:red;">No registration form available.</span>`}
      </div>
    `;
    openModal('eventModal');
  }
  
  