from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, time

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///activity.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = "supersecretkey"

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    account_type = db.Column(db.String(10), nullable=False)  # 'student' or 'admin'
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    enrollment_number = db.Column(db.String(50))
    email = db.Column(db.String(120))
    contact = db.Column(db.String(20))
    admin_key = db.Column(db.String(50))  # for admins

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    department = db.Column(db.String(50))
    date = db.Column(db.Date)
    time = db.Column(db.Time)
    registration_last_date = db.Column(db.Date)
    max_registrations = db.Column(db.Integer)
    registrations = db.Column(db.Integer, default=0)
    registration_link = db.Column(db.String(250))
    description = db.Column(db.Text)
    status = db.Column(db.String(10), default='draft')  # 'draft' or 'uploaded'
    creator_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    creator = db.relationship('User', backref='events')

with app.app_context():
    db.create_all()
    if not User.query.filter_by(account_type='admin').first():
        admin = User(account_type='admin', username='admin', admin_key='MASTER_KEY')
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json
    if not data:
        return jsonify({'error': 'No input data provided'}), 400
    account_type = data.get('account_type')
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    if not account_type or not username or not password:
        return jsonify({'error': 'Missing required fields'}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 409
    user = User(account_type=account_type, username=username)
    user.set_password(password)
    if account_type == 'student':
        user.enrollment_number = data.get('enrollment_number')
        user.email = data.get('email')
        user.contact = data.get('contact')
    elif account_type == 'admin':
        admin_key = data.get('admin_key')
        if admin_key != 'MASTER_KEY':
            return jsonify({'error': 'Invalid admin key'}), 403
        user.admin_key = admin_key
    else:
        return jsonify({'error': 'Invalid account type'}), 400
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'Registration successful'}), 201

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    if not data:
        return jsonify({'error': 'No input data provided'}), 400
    account_type = data.get('account_type')
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    admin_key = data.get('admin_key', '')
    user = User.query.filter_by(username=username, account_type=account_type).first()
    if not user or not user.check_password(password):
        return jsonify({'error': 'Invalid username or password'}), 401
    if account_type == 'admin' and admin_key != user.admin_key:
        return jsonify({'error': 'Invalid admin key'}), 403
    session['user_id'] = user.id
    session['account_type'] = account_type
    return jsonify({'message': 'Login successful', 'account_type': account_type, 'username': username})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

# API: Get ALL uploaded events - these show on the student portal!
@app.route('/api/events', methods=['GET'])
def api_get_events():
    events = Event.query.filter_by(status='uploaded').all()
    return jsonify([{
        'id': e.id,
        'title': e.title,
        'department': e.department,
        'date': e.date.isoformat() if e.date else '',
        'time': e.time.isoformat() if e.time else '',
        'registration_last_date': e.registration_last_date.isoformat() if e.registration_last_date else '',
        'max_registrations': e.max_registrations,
        'registrations': e.registrations,
        'registration_link': e.registration_link,
        'description': e.description,
    } for e in events])

# API: Admin can create/update event (make sure status "uploaded" when publishing)
@app.route('/api/events', methods=['POST'])
def api_create_update_event():
    if 'user_id' not in session or session.get('account_type') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 401
    data = request.json
    event_id = data.get('id')
    if event_id:
        event = Event.query.get(event_id)
        if not event or event.creator_id != session['user_id']:
            return jsonify({'error': 'Event not found or unauthorized'}), 404
    else:
        event = Event(creator_id=session['user_id'])
    event.title = data.get('title', event.title)
    event.department = data.get('department', event.department)
    date_str = data.get('date')
    time_str = data.get('time')
    event.date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else event.date
    event.time = datetime.strptime(time_str, '%H:%M').time() if time_str else event.time
    reg_last_str = data.get('registration_last_date')
    event.registration_last_date = datetime.strptime(reg_last_str, '%Y-%m-%d').date() if reg_last_str else event.registration_last_date
    event.max_registrations = data.get('max_registrations', event.max_registrations)
    event.registration_link = data.get('registration_link', event.registration_link)
    event.description = data.get('description', event.description)
    # Critical: status must be "uploaded" to be visible to students!
    event.status = data.get('status', 'uploaded')  
    db.session.add(event)
    db.session.commit()
    return jsonify({'message': 'Event saved', 'event_id': event.id})

@app.route('/api/events/<int:event_id>', methods=['DELETE'])
def api_delete_event(event_id):
    if 'user_id' not in session or session.get('account_type') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 401
    event = Event.query.get(event_id)
    if not event or event.creator_id != session['user_id']:
        return jsonify({'error': 'Event not found or unauthorized'}), 404
    db.session.delete(event)
    db.session.commit()
    return jsonify({'message': 'Event deleted'})

if __name__ == '__main__':
    app.run(debug=True)
