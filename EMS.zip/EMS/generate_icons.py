from PIL import Image, ImageDraw, ImageFont

size = (64, 64)
background_color = (91, 110, 248)
text_color = (255, 255, 255)
text = "E"

# Create image
image = Image.new('RGBA', size, background_color)
draw = ImageDraw.Draw(image)

try:
    font = ImageFont.truetype("arial.ttf", 40)
except IOError:
    font = ImageFont.load_default()

# Calculate text position centered
text_bbox = draw.textbbox((0, 0), text, font=font)
text_width = text_bbox[2] - text_bbox[0]
text_height = text_bbox[3] - text_bbox[1]
position = ((size[0] - text_width) // 2, (size[1] - text_height) // 2)

# Draw text
draw.text(position, text, fill=text_color, font=font)

# Save favicon.ico for browser (in your Flask static folder)
image.save("static/favicon.ico", format="ICO")

# Save PNG app_icon.png for desktop app icon
image.save("static/app_icon.png", format="PNG")
