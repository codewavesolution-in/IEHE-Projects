import multiprocessing

if __name__ == "__main__":
    multiprocessing.set_start_method("forkserver")  # or "spawn" if forkserver causes issues

    from app import app
    from flaskwebgui import FlaskUI

    ui = FlaskUI(app, width=1000, height=700)
    ui.run()
