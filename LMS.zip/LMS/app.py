from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import date, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'  # Your local DB file
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'supersecretkey'

db = SQLAlchemy(app)

# --- Models ---

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    issues = db.relationship('Issue', backref='student', lazy=True)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    year = db.Column(db.Integer)

class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    issue_date = db.Column(db.Date, nullable=False, default=date.today)
    due_date = db.Column(db.Date, nullable=False)
    return_date = db.Column(db.Date)
    fine = db.Column(db.Float, default=0.0)
    book = db.relationship('Book', lazy=True)

# --- Constants ---

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'
DAILY_FINE = 10  # Rs 10 per day late fine

with app.app_context():
    db.create_all()

# --- Routes ---

@app.route('/', methods=['GET', 'POST'])
def home():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin'))
        else:
            error = "Invalid username or password"
    return render_template('main.html', error=error)

@app.route('/admin')
def admin():
    if not session.get('admin_logged_in'):
        return redirect(url_for('home'))
    return render_template('admin.html')

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('home'))

# --- Book APIs ---

@app.route('/api/books', methods=['GET'])
def get_books():
    books = Book.query.all()
    return jsonify(books=[{'title': b.title, 'author': b.author, 'year': b.year} for b in books])

@app.route('/api/books', methods=['POST'])
def add_book_api():
    data = request.get_json()
    new_book = Book(title=data['title'], author=data['author'], year=int(data['year']))
    db.session.add(new_book)
    db.session.commit()
    return jsonify({'message': 'Book added'}), 201

@app.route('/api/books/<string:title>', methods=['DELETE'])
def delete_book_api(title):
    book = Book.query.filter_by(title=title).first()
    if book:
        db.session.delete(book)
        db.session.commit()
        return jsonify({'message': 'Book deleted'})
    return jsonify({'message': 'Book not found'}), 404

@app.route('/api/books/<string:title>', methods=['PUT'])
def modify_book_api(title):
    book = Book.query.filter_by(title=title).first()
    if not book:
        return jsonify({'message': 'Book not found'}), 404
    data = request.get_json()
    book.title = data.get('title', book.title)
    book.author = data.get('author', book.author)
    book.year = int(data.get('year', book.year))
    db.session.commit()
    return jsonify({'message': 'Book updated'})

# --- Student APIs ---

@app.route('/api/students', methods=['GET'])
def get_students():
    students = Student.query.all()
    result = []
    for s in students:
        issued_books = []
        for issue in s.issues:
            issued_books.append({
                'book_title': issue.book.title,
                'issue_date': issue.issue_date.isoformat(),
                'due_date': issue.due_date.isoformat(),
                'return_date': issue.return_date.isoformat() if issue.return_date else None,
                'fine': issue.fine
            })
        result.append({
            'id': s.id,
            'name': s.name,
            'year': s.year,
            'roll_number': s.roll_number,
            'issued_books': issued_books
        })
    return jsonify(students=result)

@app.route('/api/students', methods=['POST'])
def add_student():
    data = request.get_json()
    if Student.query.filter_by(roll_number=data['roll_number']).first():
        return jsonify({'message': 'Roll number already exists'}), 400
    student = Student(name=data['name'], year=int(data['year']), roll_number=data['roll_number'])
    db.session.add(student)
    db.session.commit()
    return jsonify({'message': 'Student added'}), 201

@app.route('/api/issue_book', methods=['POST'])
def issue_book():
    data = request.get_json()
    student_id = data['student_id']
    book_id = data['book_id']

    # Check student's current issued book count (unreturned)
    issued_count = Issue.query.filter_by(student_id=student_id, return_date=None).count()
    if issued_count >= 2:
        return jsonify({'message': 'Student already issued 2 books, cannot issue more'}), 400

    due_in_days = 14
    issue = Issue(
        student_id=student_id,
        book_id=book_id,
        issue_date=date.today(),
        due_date=date.today() + timedelta(days=due_in_days)
    )
    db.session.add(issue)
    db.session.commit()
    return jsonify({'message': 'Book issued successfully'}), 201

@app.route('/api/return_book/<int:issue_id>', methods=['POST'])
def return_book(issue_id):
    issue = Issue.query.get(issue_id)
    if not issue or issue.return_date is not None:
        return jsonify({'message': 'Invalid issue ID or book already returned'}), 400

    issue.return_date = date.today()
    # Calculate fine
    if issue.return_date > issue.due_date:
        days_late = (issue.return_date - issue.due_date).days
        issue.fine = days_late * DAILY_FINE
    else:
        issue.fine = 0.0
    db.session.commit()
    return jsonify({'message': 'Book returned', 'fine': issue.fine})

if __name__ == '__main__':
    app.run(debug=True)
