from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    password = db.Column(db.String(128), nullable=False)  # basic authentication

    # New: JSON string to store SGPA per semester
    sgpa_semesters = db.Column(db.String, nullable=True)

    # New: Activity participation flags
    sports_participated = db.Column(db.Boolean, default=False)
    cultural_participated = db.Column(db.Boolean, default=False)
    ncc_participated = db.Column(db.Boolean, default=False)
    nss_participated = db.Column(db.Boolean, default=False)

    # Original relationships
    activities = db.relationship('Participation', backref='student', lazy=True)


class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    date = db.Column(db.Date, nullable=False)
    organizer_id = db.Column(db.Integer, db.ForeignKey('teacher.id'))
    organizer = db.relationship('Teacher', backref='organized_activities')
    participants = db.relationship('Participation', backref='activity', lazy=True)

class Participation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    activity_id = db.Column(db.Integer, db.ForeignKey('activity.id'), nullable=False)
    role = db.Column(db.String(50))     # e.g. 'member', 'leader'
    status = db.Column(db.String(50))   # 'registered', 'completed', etc.

