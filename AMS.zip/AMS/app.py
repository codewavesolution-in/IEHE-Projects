from flask import Flask, render_template, redirect, url_for, request, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import date
from werkzeug.security import generate_password_hash, check_password_hash
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///activity.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'supersecretkey'

db = SQLAlchemy(app)
migrate = Migrate(app, db) 

# Models

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    password = db.Column(db.String(128), nullable=False)  # hashed password
    participations = db.relationship('Participation', backref='student', lazy=True)
    
    sgpa_semesters = db.Column(db.String, nullable=True)  # JSON string
    sports_participated = db.Column(db.Boolean, default=False)
    cultural_participated = db.Column(db.Boolean, default=False)
    ncc_participated = db.Column(db.Boolean, default=False)
    nss_participated = db.Column(db.Boolean, default=False)

class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)  # hashed password
    activities = db.relationship('Activity', backref='organizer', lazy=True)

class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    date = db.Column(db.Date, nullable=False)
    organizer_id = db.Column(db.Integer, db.ForeignKey('teacher.id'))
    participants = db.relationship('Participation', backref='activity', lazy=True)

class Participation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    activity_id = db.Column(db.Integer, db.ForeignKey('activity.id'), nullable=False)
    role = db.Column(db.String(50))     # e.g. member, leader
    status = db.Column(db.String(50))   # e.g., registered, completed

# Initialize DB and add test data if missing

with app.app_context():
    db.create_all()
    # Add test student if missing
    if not Student.query.filter_by(roll_number="S12345").first():
        hashed_pw = generate_password_hash("studpass")
        db.session.add(Student(name="Test Student", roll_number="S12345", year=3, password=hashed_pw,
                               sgpa_semesters=json.dumps({"1":"8.5","2":"8.8","3":"9.0"})))
        db.session.commit()
    # Add test teacher if missing
    if not Teacher.query.filter_by(username="teacher1").first():
        hashed_pw = generate_password_hash("teachpass")
        db.session.add(Teacher(name="Test Teacher", username="teacher1", password=hashed_pw))
        db.session.commit()

# Routes

@app.route('/')
def home():
    return render_template('home.html')

# Student Registration
@app.route('/student/register', methods=['GET', 'POST'])
def student_register():
    error = None
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        roll_number = request.form.get('roll_number', '').strip()
        year = request.form.get('year', '').strip()
        password = request.form.get('password', '').strip()
        if not all([name, roll_number, year, password]):
            error = "All fields are required."
            return render_template('student_register.html', error=error)
        if Student.query.filter_by(roll_number=roll_number).first():
            error = "Roll number already registered."
            return render_template('student_register.html', error=error)
        hashed_pw = generate_password_hash(password)
        student = Student(name=name, roll_number=roll_number, year=int(year), password=hashed_pw)
        db.session.add(student)
        db.session.commit()
        return redirect(url_for('student_login'))
    return render_template('student_register.html', error=error)

# Student Login
@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    error = None
    if request.method == 'POST':
        roll = request.form.get('roll_number')
        password = request.form.get('password')
        student = Student.query.filter_by(roll_number=roll).first()
        if student and check_password_hash(student.password, password):
            session['student_id'] = student.id
            return redirect(url_for('student_dashboard'))
        else:
            error = "Invalid roll number or password"
    return render_template('student_login.html', error=error)

# Student Dashboard
@app.route('/student/dashboard')
def student_dashboard():
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    student = Student.query.get(session['student_id'])
    participations = Participation.query.filter_by(student_id=student.id).all()
    sgpa_data = json.loads(student.sgpa_semesters) if student.sgpa_semesters else {}
    return render_template('student_detail.html', student=student, participations=participations, sgpa=sgpa_data)

# Teacher Registration
@app.route('/teacher/register', methods=['GET', 'POST'])
def teacher_register():
    error = None
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if not all([name, username, password]):
            error = "All fields are required."
            return render_template('teacher_register.html', error=error)
        if Teacher.query.filter_by(username=username).first():
            error = "Username already exists."
            return render_template('teacher_register.html', error=error)
        hashed_pw = generate_password_hash(password)
        teacher = Teacher(name=name, username=username, password=hashed_pw)
        db.session.add(teacher)
        db.session.commit()
        return redirect(url_for('teacher_login'))
    return render_template('teacher_register.html', error=error)

# Teacher Login
@app.route('/teacher/login', methods=['GET', 'POST'])
def teacher_login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        teacher = Teacher.query.filter_by(username=username).first()
        if teacher and check_password_hash(teacher.password, password):
            session['teacher_id'] = teacher.id
            return redirect(url_for('teacher_dashboard'))
        else:
            error = "Invalid username or password"
    return render_template('teacher_login.html', error=error)

# Teacher Dashboard
@app.route('/teacher/dashboard')
def teacher_dashboard():
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    teacher = Teacher.query.get(session['teacher_id'])
    activities = Activity.query.filter_by(organizer_id=teacher.id).all()
    return render_template('teacher_dashboard.html', teacher=teacher, activities=activities)

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# API to create activity
@app.route('/api/activities', methods=['GET', 'POST'])
def activities_api():
    if request.method == 'GET':
        acts = Activity.query.all()
        return jsonify([{'id': a.id, 'name': a.name, 'description': a.description, 'date': a.date.isoformat()} for a in acts])
    if 'teacher_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    data = request.get_json()
    act = Activity(
        name=data['name'],
        description=data['description'],
        date=date.fromisoformat(data['date']),
        organizer_id=session['teacher_id']
    )
    db.session.add(act)
    db.session.commit()
    return jsonify({'message': 'Activity created'}), 201

# API to get all students for teacher dashboard
@app.route('/api/students/all', methods=['GET'])
def get_all_students():
    if 'teacher_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    students = Student.query.all()
    return jsonify(students=[{
        'id': s.id,
        'name': s.name,
        'roll_number': s.roll_number,
        'year': s.year,
        'sgpa_semesters': json.loads(s.sgpa_semesters) if s.sgpa_semesters else {},
        'sports_participated': s.sports_participated,
        'cultural_participated': s.cultural_participated,
        'ncc_participated': s.ncc_participated,
        'nss_participated': s.nss_participated
    } for s in students])

# API to update student academic and participation data by teacher
@app.route('/api/students/update/<int:student_id>', methods=['POST'])
def update_student_data(student_id):
    if 'teacher_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    s = Student.query.get_or_404(student_id)
    data = request.get_json()
    s.name = data.get('name', s.name)
    s.year = data.get('year', s.year)
    sgpa_data = data.get('sgpa_semesters', {})
    s.sgpa_semesters = json.dumps(sgpa_data)
    s.sports_participated = data.get('sports_participated', s.sports_participated)
    s.cultural_participated = data.get('cultural_participated', s.cultural_participated)
    s.ncc_participated = data.get('ncc_participated', s.ncc_participated)
    s.nss_participated = data.get('nss_participated', s.nss_participated)
    db.session.commit()
    return jsonify({'message': 'Student data updated'})

# API to delete student data
@app.route('/api/students/delete/<int:student_id>', methods=['DELETE'])
def delete_student(student_id):
    if 'teacher_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    student = Student.query.get_or_404(student_id)
    db.session.delete(student)
    db.session.commit()
    return jsonify({'message': f'Student {student.name} deleted'})

if __name__ == '__main__':
    app.run(debug=True)
