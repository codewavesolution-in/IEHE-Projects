// Simple demo interactivity: fake login + adjustable attendance/GPA
document.getElementById('loginForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const btn = e.target.querySelector('.btn-primary');
  const original = btn.textContent;
  btn.textContent = 'Logging in...';
  btn.disabled = true;
  setTimeout(()=>{
    btn.textContent = original;
    btn.disabled = false;
    alert('Logged in (demo)');
  }, 900);
});

document.getElementById('forgotBtn').addEventListener('click', ()=>{
  const email = prompt('Enter registered email to reset password (demo):');
  if(email){
    alert('Password reset link sent to: ' + email);
  }
});

// Optional: change GPA and attendance dynamically (demo)
(function demoMetrics(){
  const gpaEl = document.getElementById('gpaValue');
  let gpa = 3.8;
  setInterval(()=>{
    const delta = (Math.random() - 0.5) * 0.04;
    gpa = Math.min(4.0, Math.max(2.5, +(gpa + delta).toFixed(2)));
    gpaEl.textContent = gpa.toFixed(2);
    // attendance bar wiggle
    const bar = document.querySelector('.progress .bar');
    const w = 88 + Math.round(Math.random()*6);
    bar.style.width = w + '%';
    bar.parentElement.nextElementSibling.textContent = w + '%';
  }, 4000);
})();
