// ==================== Existing Code ====================

// Mobile nav toggle for all pages
const hamb = document.getElementById('hamburger');
const nav = document.querySelector('.nav');
if (hamb && nav) {
  hamb.addEventListener('click', () => {
    const open = nav.style.display === 'flex';
    nav.style.display = open ? 'none' : 'flex';
    nav.style.flexDirection = 'column';
    nav.style.alignItems = 'flex-end';
  });
}

// Subtle CTA pulse on Home if present
const applyBtn = document.getElementById('applyBtn');
if (applyBtn) {
  setInterval(() => {
    applyBtn.style.transform = 'translateY(-1px) scale(1.01)';
    applyBtn.style.boxShadow = '0 14px 28px rgba(47,107,237,.38)';
    setTimeout(() => {
      applyBtn.style.transform = '';
      applyBtn.style.boxShadow = '';
    }, 260);
  }, 4500);
}

// Helper to bind simple demo login behavior
function bindDemoLogin(formId, role) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('.btn-primary');
    const original = btn.textContent;
    btn.textContent = 'Signing in...';
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = original;
      btn.disabled = false;
      // Redirect to a placeholder dashboard route
      alert(role + ' login successful (demo). Redirecting to dashboard...');
      // Replace with your real route:
      window.location.href = 'index.html';
    }, 900);
  });
}

// ==================== New Modal Code ====================

// Function to bind modal open/close
function bindModal(triggerId, modalId) {
  const trigger = document.getElementById(triggerId);
  const modal = document.getElementById(modalId);
  if (!trigger || !modal) return;

  const closeBtn = modal.querySelector(".modal-close");

  trigger.addEventListener("click", () => {
    modal.setAttribute("aria-hidden", "false");
    // let CSS animate
    setTimeout(() => modal.classList.add("show"), 10);
  });

  closeBtn.addEventListener("click", () => {
    modal.classList.remove("show");
    setTimeout(() => modal.setAttribute("aria-hidden", "true"), 250);
  });

  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.classList.remove("show");
      setTimeout(() => modal.setAttribute("aria-hidden", "true"), 250);
    }
  });
}

// Bind modals for info items
bindModal("achievementsTrigger", "achievementsModal");
bindModal("analyticsTrigger", "analyticsModal");
bindModal("clubsTrigger", "clubsModal");
